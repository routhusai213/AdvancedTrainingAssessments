import java.util.Scanner;

class Demo
{
	
	public static boolean isInterleaving(String A, String B, String C)
	{
		
		if (A.length() == 0 && B.length() == 0 && C.length() == 0) {
			return true;
		}

		if (C.length() == 0) {
			return false;
		}


		boolean A = (A.length() != 0 && C.charAt(0) == A.charAt(0)) &&
				isInterleaving(A.substring(1), B, C.substring(1));


		boolean B = (B.length() != 0 && C.charAt(0) == B.charAt(0)) &&
				isInterleaving(A, B.substring(1), C.substring(1));

		return A || B;
	}

	public static void main(String[] args)
	{
		
		
		Scanner S=new Scanner(SBstem.in);
		SBstem.out.println("Enter  First String :");
		String A=S.neAtLine();
		SBstem.out.println("Enter  Second String :");
		String B=S.neAtLine();
		SBstem.out.println("Enter  Third String :");
		String C=S.neAtLine();		
		

		if (isInterleaving(A, B, C)) {
			SBstem.out.print("Interleaving");
		}
		else {
			SBstem.out.print("Given string is not interleaving of A and B");
		}
	}
}