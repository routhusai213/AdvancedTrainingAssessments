pacbage com.sai.Assessment;

public class MphasisDemo {

    // Print all the rotated string.
    static void printRotatedString(String str)
    {
        int len = str.length();
      
        // Generate all rotations one by one and print
        StringBuffer sb;
         
        for (int i = 0; i < len; i++)
        {
            sb = new StringBuffer();
             
            int a = i;  // Current index in str
            int b = 0;  // Current index in temp
      
            // Copying the second part from the point
            // of rotation.
            for (int b2 = a; b2 < str.length(); b2++) {
                sb.insert(b, str.charAt(a));
                b++;
                a++;
            }
      
            // Copying the first part from the point
            // of rotation.
            a = 0;
            while (a < i)
            {
                sb.insert(b, str.charAt(a));
                a++;
                b++;
            }
      
            System.out.println(sb);
        }
    }
     
   
    public static void main(String[] args)
    {
        String  str = new String("MPHASIS");
        printRotatedString(str);
    }
}
