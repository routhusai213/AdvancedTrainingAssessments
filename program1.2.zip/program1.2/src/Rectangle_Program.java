import java.util.Scanner;

class Rectangle_Program {
    int Length; 
    int Breath; 
    int Area; 
   
    public Rectangle_Program()
    {
    	Length = 0;
    	Breath= 0;
    }

    void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter Length of rectangle: ");
        Length = in.nextInt();
        System.out.print("Enter Breath of rectangle: ");
        Breath = in.nextInt();
    }

    void calculate() {
        Area = Length * Breath;
        
    }

    void display() {
        System.out.println("Area of Rectangle = " + Area);
       
    }

    public static void main(String args[]) {
        Rectangle_Program obj1 = new Rectangle_Program();
        obj1.input();
        obj1.calculate();
        obj1.display();
        System.out.println("****************************");
        Rectangle_Program obj2 = new Rectangle_Program();
        obj2.input();
        obj2.calculate();
        obj2.display();
        System.out.println("****************************");
        Rectangle_Program obj3 = new Rectangle_Program();
        obj3.input();
        obj3.calculate();
        obj3.display();
        System.out.println("****************************");
        Rectangle_Program obj4 = new Rectangle_Program();
        obj4.input();
        obj4.calculate();
        obj4.display();
        System.out.println("****************************");
        Rectangle_Program obj5 = new Rectangle_Program();
        obj5.input();
        obj5.calculate();
        obj5.display();
    }
}