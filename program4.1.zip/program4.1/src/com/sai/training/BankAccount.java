package com.sai.Assessment;

class BankAccount {
    int accountNumber;
    String name;
    String accountType;
    double Balance;
   
    public int getaccountNumber() {
        return accountNumber;
    }
   
    public void setaccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }
   
    public String getName() {
        return name;
    }
   
    public void setName(String name) {
        this.name = name;
    }
   
    public String getaccountType() {
        return accountType;
    }
   
    public void setaccountType(String accountType) {
        this.accountType = accountType;
    }
   
    public double getBalance() {
       
        if( Balance <1000)
        {
        try
        {   
            throw new NumberFormatException();
        }
        catch(NumberFormatException nw)
        {
            System.out.println("Balance is low"+Balance);
        }
        }
       
       
        return Balance;
       
    }
    public void setBalance(double Balance) {
        this.Balance = Balance;
    }//end setter and getter

    public BankAccount() {
       
        this.accountNumber = 100;
        this.name = "AMOl";
        this.accountType = "Saving";
        this.Balance = 500;
    }
   
   
   
   
    public BankAccount(int accountNumber, String name, String accountType,
            double Balance) {
       
        this.accountNumber = accountNumber;
        this.name = name;
        this.accountType = accountType;
        this.Balance = Balance;
    }
    void deposit(double amt)
    {
        if(amt<0)
        {
            try
            {
                throw new NumberFormatException();
            }
            catch(NumberFormatException nf)
            {
                System.out.println("Negaive Amount cant be deposited");
            }
        }
        else
        {
            Balance=getBalance()+amt;
            System.out.println("Current Balance is ="+Balance);
           
        }
       
       
       
    }
     public void withdraw(double amt){
         if(amt>1000)
            {
                try
                {
                    throw new NumberFormatException();
                }
                catch(NumberFormatException nf)
                {
                    System.out.println("WE CANT DEPOSITE AMOUNT INSUFFICENT Balance ");
                }
            }
            else
            {
                Balance=getBalance()-amt;
                System.out.println("Current Balance is ="+Balance);
               
            }
       
       
       
       
       
    }
     void display()
     {
    System.out.println("Balance is ="+getBalance());   
     }
   
   
   
   
    public static void main(String[] args) {
       
       
        BankAccount b=new BankAccount();
        b.deposit(2000);
        b.display();
        b.withdraw(500);
        b.display();
        b.withdraw(2000);
        b.getBalance();
        b.display();
       
       
       
    }
   
   
   
   
}