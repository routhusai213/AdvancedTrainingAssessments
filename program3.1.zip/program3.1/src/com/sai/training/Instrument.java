package com.sai.Assessment;

public abstract class Instrument {
	public abstract void play();
}
