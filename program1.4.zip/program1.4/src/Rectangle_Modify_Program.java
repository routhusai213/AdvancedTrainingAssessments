import java.util.Scanner;

class Rectangle_Modify_Program {
    int Length; 
    int Width; 
    int Area; 
    int Parameter;
    
    public int getLength() {
		return Length;
	}

	public void setLength(int Length) {
		this.Length = Length;
	}

	public int getWidth() {
		return Width;
	}

	public void setWidth(int Width) {
		this.Width = Width;
	}

	
    public Rectangle_Modify_Program()
    {
    	Length = 1;
    	Width= 1;
    }

    void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter Length of rectangle: ");
        Length = in.nextInt();
        System.out.print("Enter Width of rectangle: ");
        Width = in.nextInt();
    }
    
    void  AreaRectangle()
    {
        Area = Length * Width;
       
    }
 
     void  perimeterRectangle()
    {
    	 Parameter = 2*(Length + Width);
       
    }

    void display() {
    	if(Length>0 && Length<20)
        {
        System.out.println("Area of Rectangle = " + Area);
        System.out.println("Parameter of Rectangle = " +Parameter);}
       
        }

    public static void main(String args[]) {
    	
        Rectangle_Modify_Program obj1 = new Rectangle_Modify_Program();
        obj1.input();
        obj1.AreaRectangle();
        obj1.perimeterRectangle();
        obj1.display();
        System.out.println("============================");
        Rectangle_Modify_Program obj2 = new Rectangle_Modify_Program();
        obj2.input();
        obj2.AreaRectangle();
        obj2.perimeterRectangle();
        obj2.display();
        System.out.println("=============================");
        Rectangle_Modify_Program obj3 = new Rectangle_Modify_Program();
        obj3.input();
        obj3.AreaRectangle();
        obj3.perimeterRectangle();
        obj3.display();
        System.out.println("=============================");
        Rectangle_Modify_Program obj4 = new Rectangle_Modify_Program();
        obj4.input();
        obj4.AreaRectangle();
        obj4.perimeterRectangle();
        obj4.display();
        System.out.println("==============================");
        Rectangle_Modify_Program obj5 = new Rectangle_Modify_Program();
        obj5.input();
        obj5.AreaRectangle();
        obj5.perimeterRectangle();
        obj5.display();
    	
    }
}